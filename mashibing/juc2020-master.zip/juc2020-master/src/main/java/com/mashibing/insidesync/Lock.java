package com.mashibing.insidesync;

public class Lock {
    int m = 0;
}
