package com.mashibing.juc.c_022_RefTypeAndThreadLocal;

import java.nio.ByteBuffer;

public class TestDirectByteBuffer {
    ByteBuffer buffer = ByteBuffer.allocateDirect(1024);


}
