/**
 * ��ʶExecutors
 */
package com.mashibing.juc.c_026_01_ThreadPool;

public class T04_Executors {
    public static void main(String[] args) {
        //Executors
    }
}
