package com.mashibing;

import com.mashibing.util.SleepHelper;
import org.openjdk.jol.info.ClassLayout;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;

public class JustTest { //JOL = Java Object Layout

    private static class T {

    }

    public static void main(String[] args) {
        T t = new T();
        System.out.println(ClassLayout.parseInstance(t).toPrintable());

        synchronized (t) {
            System.out.println(ClassLayout.parseInstance(t).toPrintable());
        }

        System.out.println(ClassLayout.parseInstance(t).toPrintable());

    }
}



