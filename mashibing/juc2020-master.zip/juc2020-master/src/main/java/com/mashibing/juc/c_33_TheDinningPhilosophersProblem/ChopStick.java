package com.mashibing.juc.c_33_TheDinningPhilosophersProblem;

public class ChopStick {
}
