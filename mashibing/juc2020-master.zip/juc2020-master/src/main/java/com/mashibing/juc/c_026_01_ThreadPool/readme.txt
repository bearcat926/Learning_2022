﻿Executor 
ExecutorService submit
Callable = Runnable
Executors 
ThreadPool
Future

fixed cached single scheduled workstealing forkjoin

ThreadpoolExecutor

PStreamAPI