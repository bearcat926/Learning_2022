package com.mashibing.juc.c_001_03_Ordering;

public class T {
    public static void main(String[] args) {
        Object o = new Object();
    }
}
