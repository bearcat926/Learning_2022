package com.mashibing.juc.c_023_02_FromHashtableToCHM;

public class Constants {
    public static final int COUNT = 1000000;
    public static final int THREAD_COUNT = 100;

}
