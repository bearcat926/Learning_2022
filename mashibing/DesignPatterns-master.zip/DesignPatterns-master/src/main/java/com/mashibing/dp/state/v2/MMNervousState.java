package com.mashibing.dp.state.v2;

public class MMNervousState extends MMState {
    @Override
    void smile() {

    }

    @Override
    void cry() {

    }

    @Override
    void say() {

    }
}
