package com.mashibing.dp.Iterator.v4;

public interface Collection_ {
    void add(Object o);
    int size();
}
