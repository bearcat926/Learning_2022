package com.mashibing.dp.ASM;

public class Tank {
    public void move(){
        System.out.println("Tank Moving ClaClaCla ...");
    }
}
