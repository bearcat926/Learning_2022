package com.mashibing.dp.Iterator.v5;

public interface Collection_ {
    void add(Object o);
    int size();

    Iterator_ iterator();
}
