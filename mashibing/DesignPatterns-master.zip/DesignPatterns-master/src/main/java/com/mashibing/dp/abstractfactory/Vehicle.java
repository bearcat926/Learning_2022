package com.mashibing.dp.abstractfactory;

public abstract class Vehicle { //interface
    abstract void go();
}
