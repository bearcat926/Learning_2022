package com.mashibing.dp.abstractfactory;

public abstract class Weapon {
    abstract void shoot();
}
