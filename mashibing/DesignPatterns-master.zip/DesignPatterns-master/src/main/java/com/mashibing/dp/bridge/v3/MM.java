package com.mashibing.dp.bridge.v3;

public class MM {
    String name;
}
