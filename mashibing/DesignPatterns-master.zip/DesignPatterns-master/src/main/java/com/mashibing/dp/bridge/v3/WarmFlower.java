package com.mashibing.dp.bridge.v3;

/**
 * 或者从WarmGift继承
 * 或者从Flower继承
 */
public class WarmFlower extends Flower {
}
