package com.mashibing.dp.bridge.v1;

public class MM {
    String name;
}
