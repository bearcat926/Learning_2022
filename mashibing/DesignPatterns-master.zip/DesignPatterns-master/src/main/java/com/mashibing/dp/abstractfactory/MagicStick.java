package com.mashibing.dp.abstractfactory;

public class MagicStick extends Weapon{
    public void shoot() {
        System.out.println("diandian....");
    }
}
