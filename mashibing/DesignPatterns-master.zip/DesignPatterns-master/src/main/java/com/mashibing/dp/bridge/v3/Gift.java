package com.mashibing.dp.bridge.v3;

public abstract class Gift {}
