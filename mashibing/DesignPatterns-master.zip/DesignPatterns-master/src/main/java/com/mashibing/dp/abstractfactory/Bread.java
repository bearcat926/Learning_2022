package com.mashibing.dp.abstractfactory;

public class Bread extends Food{
    public void printName() {
        System.out.println("wdm");
    }
}
