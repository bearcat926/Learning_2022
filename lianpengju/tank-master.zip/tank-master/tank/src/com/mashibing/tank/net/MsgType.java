package com.mashibing.tank.net;

public enum MsgType {
	TankJoin, TankDirChanged, TankStop, TankStartMoving, BulletNew, TankDie
}

