package com.mashibing.tank;

public enum Group {
	GOOD, BAD
}
